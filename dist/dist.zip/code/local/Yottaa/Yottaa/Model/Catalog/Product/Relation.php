<?php

class Yottaa_Yottaa_Model_Catalog_Product_Relation extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('catalog/product_relation');
    }
}
