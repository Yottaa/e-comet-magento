<?php

class Yottaa_Yottaa_Model_Catalog_Category_Product extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('yottaa_yottaa/catalog_category_product');
    }
}
